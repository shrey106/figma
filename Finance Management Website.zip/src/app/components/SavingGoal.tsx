import React from 'react';
import { Target } from 'lucide-react';

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  icon: string;
}

interface SavingGoalProps {
  goal: Goal;
  onAddFunds: (goalId: string, amount: number) => void;
}

export function SavingGoal({ goal, onAddFunds }: SavingGoalProps) {
  const progress = (goal.currentAmount / goal.targetAmount) * 100;
  const remaining = goal.targetAmount - goal.currentAmount;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-100 text-indigo-600 p-3 rounded-lg">
            <span className="text-2xl">{goal.icon}</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">{goal.name}</h4>
            <p className="text-sm text-gray-500">Target by {goal.deadline}</p>
          </div>
        </div>
        <Target className="w-5 h-5 text-gray-400" />
      </div>
      
      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Progress</span>
          <span className="font-semibold text-gray-900">
            ${goal.currentAmount.toLocaleString()} / ${goal.targetAmount.toLocaleString()}
          </span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-300"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
        
        <div className="flex justify-between items-center pt-2">
          <span className="text-sm text-gray-600">
            {progress.toFixed(1)}% complete
          </span>
          <span className="text-sm font-medium text-indigo-600">
            ${remaining.toLocaleString()} remaining
          </span>
        </div>
      </div>
    </div>
  );
}
