import React from 'react';
import { ShoppingBag, Coffee, Home, Car, Heart, MoreHorizontal } from 'lucide-react';

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
}

interface ExpenseItemProps {
  expense: Expense;
}

const categoryIcons: Record<string, any> = {
  Shopping: ShoppingBag,
  Food: Coffee,
  Housing: Home,
  Transportation: Car,
  Healthcare: Heart,
  Other: MoreHorizontal,
};

const categoryColors: Record<string, string> = {
  Shopping: 'bg-purple-100 text-purple-600',
  Food: 'bg-orange-100 text-orange-600',
  Housing: 'bg-blue-100 text-blue-600',
  Transportation: 'bg-green-100 text-green-600',
  Healthcare: 'bg-red-100 text-red-600',
  Other: 'bg-gray-100 text-gray-600',
};

export function ExpenseItem({ expense }: ExpenseItemProps) {
  const Icon = categoryIcons[expense.category] || MoreHorizontal;
  const colorClass = categoryColors[expense.category] || 'bg-gray-100 text-gray-600';

  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4">
        <div className={`${colorClass} p-3 rounded-lg`}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <h4 className="font-medium text-gray-900">{expense.description}</h4>
          <p className="text-sm text-gray-500">{expense.category} • {expense.date}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-semibold text-red-600">-${expense.amount.toFixed(2)}</p>
      </div>
    </div>
  );
}
