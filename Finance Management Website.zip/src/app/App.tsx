import React, { useState } from 'react';
import { 
  Wallet, 
  TrendingDown, 
  PiggyBank, 
  Target,
  Plus,
  Calendar,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { DashboardCard } from '@/app/components/DashboardCard';
import { ExpenseItem, Expense } from '@/app/components/ExpenseItem';
import { SavingGoal, Goal } from '@/app/components/SavingGoal';
import { AddExpenseModal } from '@/app/components/AddExpenseModal';
import { AddSavingsModal } from '@/app/components/AddSavingsModal';
import { AddGoalModal } from '@/app/components/AddGoalModal';

const COLORS = ['#8b5cf6', '#f97316', '#3b82f6', '#10b981', '#ef4444', '#6b7280'];

export default function App() {
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: '1', category: 'Food', description: 'Grocery shopping', amount: 156.32, date: '2026-01-24' },
    { id: '2', category: 'Transportation', description: 'Gas station', amount: 45.00, date: '2026-01-23' },
    { id: '3', category: 'Shopping', description: 'New shoes', amount: 89.99, date: '2026-01-22' },
    { id: '4', category: 'Housing', description: 'Electricity bill', amount: 120.50, date: '2026-01-21' },
    { id: '5', category: 'Food', description: 'Restaurant dinner', amount: 67.25, date: '2026-01-20' },
  ]);

  const [savings, setSavings] = useState(8450.00);
  
  const [goals, setGoals] = useState<Goal[]>([
    { 
      id: '1', 
      name: 'Emergency Fund', 
      targetAmount: 10000, 
      currentAmount: 6500, 
      deadline: 'Dec 2026',
      icon: '💰'
    },
    { 
      id: '2', 
      name: 'Dream Vacation', 
      targetAmount: 5000, 
      currentAmount: 2300, 
      deadline: 'Jun 2027',
      icon: '✈️'
    },
    { 
      id: '3', 
      name: 'New Car', 
      targetAmount: 25000, 
      currentAmount: 8200, 
      deadline: 'Dec 2027',
      icon: '🚗'
    },
  ]);

  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isSavingsModalOpen, setIsSavingsModalOpen] = useState(false);
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);

  // Calculate totals
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalBalance = savings - totalExpenses;
  const totalGoalProgress = goals.reduce((sum, goal) => sum + goal.currentAmount, 0);

  // Expense trend data (last 7 days)
  const expenseTrendData = [
    { date: 'Jan 20', amount: 67.25 },
    { date: 'Jan 21', amount: 120.50 },
    { date: 'Jan 22', amount: 89.99 },
    { date: 'Jan 23', amount: 45.00 },
    { date: 'Jan 24', amount: 156.32 },
    { date: 'Jan 25', amount: 0 },
    { date: 'Jan 26', amount: 0 },
  ];

  // Category breakdown
  const categoryData = expenses.reduce((acc, expense) => {
    const existing = acc.find(item => item.name === expense.category);
    if (existing) {
      existing.value += expense.amount;
    } else {
      acc.push({ name: expense.category, value: expense.amount });
    }
    return acc;
  }, [] as Array<{ name: string; value: number }>);

  const handleAddExpense = (newExpense: Omit<Expense, 'id'>) => {
    const expense: Expense = {
      ...newExpense,
      id: Date.now().toString(),
    };
    setExpenses([expense, ...expenses]);
  };

  const handleAddSavings = (amount: number) => {
    setSavings(savings + amount);
  };

  const handleAddGoal = (newGoal: Omit<Goal, 'id' | 'currentAmount'>) => {
    const goal: Goal = {
      ...newGoal,
      id: Date.now().toString(),
      currentAmount: 0,
    };
    setGoals([...goals, goal]);
  };

  const handleAddFundsToGoal = (goalId: string, amount: number) => {
    setGoals(goals.map(goal => 
      goal.id === goalId 
        ? { ...goal, currentAmount: goal.currentAmount + amount }
        : goal
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-3 rounded-xl">
                <Wallet className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Finance Manager</h1>
                <p className="text-sm text-gray-500">Track your expenses and reach your goals</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Calendar className="w-4 h-4" />
              <span>January 26, 2026</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <DashboardCard
            title="Total Balance"
            value={`$${totalBalance.toFixed(2)}`}
            icon={Wallet}
            trend={{ value: '12.5% from last month', isPositive: true }}
            iconBgColor="bg-indigo-100"
            iconColor="text-indigo-600"
          />
          <DashboardCard
            title="Total Expenses"
            value={`$${totalExpenses.toFixed(2)}`}
            icon={TrendingDown}
            trend={{ value: '8.3% from last month', isPositive: false }}
            iconBgColor="bg-red-100"
            iconColor="text-red-600"
          />
          <DashboardCard
            title="Total Savings"
            value={`$${savings.toFixed(2)}`}
            icon={PiggyBank}
            trend={{ value: '15.2% from last month', isPositive: true }}
            iconBgColor="bg-green-100"
            iconColor="text-green-600"
          />
          <DashboardCard
            title="Goals Progress"
            value={`$${totalGoalProgress.toFixed(2)}`}
            icon={Target}
            iconBgColor="bg-purple-100"
            iconColor="text-purple-600"
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Expense Trend Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Trend (Last 7 Days)</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={expenseTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#6366f1" 
                  strokeWidth={3}
                  dot={{ fill: '#6366f1', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Category Breakdown Chart */}
          <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Expenses by Category</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                  formatter={(value: number) => `$${value.toFixed(2)}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Expenses & Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Recent Expenses List */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Recent Expenses</h3>
              <button
                onClick={() => setIsExpenseModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Expense
              </button>
            </div>
            <div className="space-y-3">
              {expenses.slice(0, 5).map(expense => (
                <ExpenseItem key={expense.id} expense={expense} />
              ))}
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl shadow-sm p-6 text-white">
            <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button
                onClick={() => setIsExpenseModalOpen(true)}
                className="w-full flex items-center gap-3 p-4 bg-white/10 hover:bg-white/20 rounded-lg transition-colors backdrop-blur-sm"
              >
                <ArrowDownRight className="w-5 h-5" />
                <span className="font-medium">Add Expense</span>
              </button>
              <button
                onClick={() => setIsSavingsModalOpen(true)}
                className="w-full flex items-center gap-3 p-4 bg-white/10 hover:bg-white/20 rounded-lg transition-colors backdrop-blur-sm"
              >
                <ArrowUpRight className="w-5 h-5" />
                <span className="font-medium">Add Savings</span>
              </button>
              <button
                onClick={() => setIsGoalModalOpen(true)}
                className="w-full flex items-center gap-3 p-4 bg-white/10 hover:bg-white/20 rounded-lg transition-colors backdrop-blur-sm"
              >
                <Target className="w-5 h-5" />
                <span className="font-medium">Create Goal</span>
              </button>
            </div>
            
            <div className="mt-6 pt-6 border-t border-white/20">
              <p className="text-sm text-white/80 mb-2">This Month's Summary</p>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-white/70">Total Spent</span>
                  <span className="font-semibold">${totalExpenses.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/70">Avg. Daily</span>
                  <span className="font-semibold">${(totalExpenses / 7).toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Saving Goals Section */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Saving Goals</h3>
              <p className="text-sm text-gray-500 mt-1">Track your progress towards your financial goals</p>
            </div>
            <button
              onClick={() => setIsGoalModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              New Goal
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {goals.map(goal => (
              <SavingGoal 
                key={goal.id} 
                goal={goal} 
                onAddFunds={handleAddFundsToGoal}
              />
            ))}
          </div>
        </div>
      </main>

      {/* Modals */}
      <AddExpenseModal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        onAdd={handleAddExpense}
      />
      <AddSavingsModal
        isOpen={isSavingsModalOpen}
        onClose={() => setIsSavingsModalOpen(false)}
        onAdd={handleAddSavings}
      />
      <AddGoalModal
        isOpen={isGoalModalOpen}
        onClose={() => setIsGoalModalOpen(false)}
        onAdd={handleAddGoal}
      />
    </div>
  );
}
