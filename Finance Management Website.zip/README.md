
  # Finance Management Website

  This is a code bundle for Finance Management Website. The original project is available at https://www.figma.com/design/vJY97VXQ3xcBkAFIQJOIYJ/Finance-Management-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  